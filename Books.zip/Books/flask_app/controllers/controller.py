from xmlrpc.client import boolean
from flask_app.models.fav import Favorites
from flask import render_template,redirect,request,session,flash
from flask_app.models.authors import Author
from flask_app.models.books import Book
from flask import Flask, render_template, request, redirect
from flask_app.templates import app

print('test')

@app.route("/authors")
def authors():
    return render_template("author.html", authors = Author.get_all())

@app.route("/author/<int:id_1>")
def author(id_1):
    hi = {
        'id': id_1
    }
    x = Author.get_one(hi)
    data = {
        'name': x[0]['name'],
        'id': x[0]['id']
    }
    y = Favorites.get_one_author(hi)
    if type(y) == bool:
        return redirect('/authors')
    return render_template("fav.html", authors = Author.get_all(), books = Book.get_all(), author = data, favorites = y)

@app.route("/book/<int:id_1>")
def big_book(id_1):

    oop = {
        'id': id_1
    }
    x = Book.get_one(oop)
    data = {
        'title': x[0]['title'],
        'id': x[0]['id']
    }
    return render_template("book_fav.html", books = Book.get_all(), authors = Author.get_all(), book=data, favorites = Favorites.get_one_book(oop))

@app.route("/books")
def books():

    return render_template("book.html", books = Book.get_all())

@app.route("/create/book", methods=['POST'])
def create_book():
    data = {
            'title': request.form['title'],
            'num_of_pages': request.form['num_of_pages']
        }
    Book.save(data)
    return redirect('/books')

@app.route("/create/author", methods=['POST'])
def create_author():
    data = {
        'name': request.form['name']
        
    }
    Author.save(data)
    return redirect('/authors')

@app.route("/add/fav/author", methods=['POST'])
def create_author_3():
    data = {
        'author_id': request.form['author_idd'],
        'book_id': request.form['book_id']
    }
    Favorites.save(data)
    return redirect('/authors')

@app.route("/add/fav/book", methods=['POST'])
def create_():
    data = {
        'author_id': request.form['author_id'],
        'book_id': request.form['book_id']
    }
    Favorites.save(data)
    return redirect('/authors')