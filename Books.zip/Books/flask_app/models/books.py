from flask_app.config.mysqlconnection import connectToMySQL

class Book:
    def __init__( self , data):
        self.title = data['title']
        self.id = data['id']
        self.num_of_pages = data['num_of_pages']
    @classmethod
    def save(cls, data ):
        query = "INSERT INTO books ( title, num_of_pages ) VALUES ( %(title)s,  %(num_of_pages)s);"
        return connectToMySQL('books_authors').query_db( query, data )
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM books;"
        results = connectToMySQL('books_authors').query_db(query)
        authors = []
        for author in results:
            authors.append( cls(author) )
        return authors
    @staticmethod
    def get_one(data ):
        query = "SELECT * FROM books WHERE id = %(id)s;"
        return connectToMySQL('books_authors').query_db( query, data )
        
