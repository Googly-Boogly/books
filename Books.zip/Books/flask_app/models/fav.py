from flask_app.config.mysqlconnection import connectToMySQL

class Favorites:
    def __init__( self , data):
        self.id = data['id']
        self.author_id = data['author_id']
        self.book_id = data['book_id']
    @classmethod
    def save(cls, data ):
        query = "INSERT INTO favorites ( author_id, book_id ) VALUES ( %(author_id)s,  %(book_id)s);"
        return connectToMySQL('books_authors').query_db( query, data )
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM favorites;"
        results = connectToMySQL('books_authors').query_db(query)
        authors = []
        for author in results:
            authors.append( cls(author) )
        return authors
    @staticmethod
    def get_one_author(data ):
        query = "SELECT author_id, book_id, books.title FROM favorites LEFT JOIN books ON favorites.book_id=books.id WHERE favorites.author_id=%(id)s;"
        return connectToMySQL('books_authors').query_db( query, data )
    @staticmethod
    def get_one_book(data ):
        query = "SELECT author_id, book_id, authors.name FROM favorites LEFT JOIN authors ON favorites.author_id=authors.id WHERE favorites.book_id=%(id)s;"
        return connectToMySQL('books_authors').query_db( query, data )