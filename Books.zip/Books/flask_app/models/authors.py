from flask_app.config.mysqlconnection import connectToMySQL

class Author:
    def __init__( self , data):
        self.id = data['id']
        self.name = data['name']
    @classmethod
    def save(cls, data ):
        query = "INSERT INTO authors ( name ) VALUES ( %(name)s );"
        return connectToMySQL('books_authors').query_db( query, data )
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM authors;"
        results = connectToMySQL('books_authors').query_db(query)
        authors = []
        for author in results:
            authors.append( cls(author) )
        return authors
    @staticmethod
    def get_one(data ):
        query = "SELECT * FROM authors WHERE id = %(id)s;"
        return connectToMySQL('books_authors').query_db( query, data )
